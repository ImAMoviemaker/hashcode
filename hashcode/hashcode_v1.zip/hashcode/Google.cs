﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace hashcode
{
    /// <summary>
    /// Processing the books/deliveries
    /// </summary>
    class Google
    {
        private Library[] libs;
        private int bCount;
        private int lCount;
        private int dCount;
        private List<int> ids;

        private Dictionary<int, List<int>> sLibs = new Dictionary<int, List<int>>();

         public void start()
        {
            Console.WriteLine("Starting");
            readInput("E:\\google\\in\\a_example.txt");

            //Logic
            logicOneToOneMapping();

            //Output
            createOutput("E:\\google\\out\\a_example.txt", sLibs);
        }


        private void logicOneToOneMapping()
        {
            int libCount = 0;
            foreach(Library lib in libs)
            {
                sLibs.Add(libCount, lib.ids);
                libCount++;
            }
        }





        private void readInput(string path)
        {
            // Read file
            string[] lines = System.IO.File.ReadAllLines(path);

            //Init Array
            libs = new Library[(lines.Length - 2)/2];
            //Get Book, Lib and day count
            bCount = Convert.ToInt32(lines[0].Split(' ')[0]);
            lCount = Convert.ToInt32(lines[0].Split(' ')[1]);
            dCount = Convert.ToInt32(lines[0].Split(' ')[2]);

            //Get score points
            ids = lines[1].Split(' ').Select(Int32.Parse).ToList() ;

            int libCounter = 0;
            for(int i = 2; i < lines.Length; i = i + 2)
            {
                libs[libCounter] = new Library(Convert.ToInt32(lines[i].Split(' ')[0]), Convert.ToInt32(lines[i].Split(' ')[1]), Convert.ToInt32(lines[i].Split(' ')[2]), lines[i + 1].Split(' ').Select(Int32.Parse).ToList());
                libCounter++;
            }

            Console.WriteLine("Reading finished");
        }

        private void createOutput(string path, Dictionary<int, List<int>> libsOut)
        {
            string outText;
            outText = libsOut.Count.ToString() + "\n";
            foreach(KeyValuePair<int, List<int>> libOut in libsOut)
            {
                outText += libOut.Key + " " + libOut.Value.Count + "\n";
                foreach(int id in libOut.Value)
                {
                    outText += id + " ";
                }
                outText = outText.Substring(0, outText.Length - 1) + "\n";
            }

            System.IO.File.WriteAllText(path, outText);

            Console.WriteLine("File written");
        }
    }
}